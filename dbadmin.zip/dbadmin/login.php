<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset ="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
    
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">

<title>Login</title>
</head>

<body style="background-color:#08192A">


<div class="cont-login">
<div class="form" action="" method="POST">
<div class="row">
    <label style="color:#535252;">Username<label/>
<input type="text" name ="username" placeholder="Enter Your Username" required>
</div>
<div class="row">
<label" style="color:#535252;" >Password<label/>
<input type="password" name ="password" placeholder="Enter Your Password" required>



</div>
<!---<a href="registration.php" ><input type="submit" value="Sign Up" class="btn btn-primary"></a>-->

<input type="submit" value="Login"  name="submit" class="btn btn-success">
</div></div>
</body>


 
<?php


// if (isset($_POST["submit"])) {
session_start();    



$conn = mysqli_connect("localhost","root","","dashboard");



$username = $_POST["username"];
$password = $_POST["password"];

$query =   "SELECT * FROM `admin` WHERE `username` = '$username' AND `password` = '$password'";



$result = mysqli_query($conn,$query);

if(mysqli_num_rows($result))
{
    while($data  = mysqli_fetch_assoc($result)){
            $_SESSION["username"]  = $data["username"];
            header('Location: index.php');

    }
}else{
    echo "invalid username or password";
}   

// }



?>


<!-- 
//
   // $username =$_POST['username'];
  //  $password = $_POST['password'];
      
      
//$conn = mysqli_connect("localhost","root","","dashboard");
//if(!$conn){
 //   echo "connection failed";
//}
//else{
 //   echo "connection success";
//}
//$query="select * from admin where username='$username' && password='$password'";
//$result = mysqli_query($conn, $query);

//$row = mysqli_fetch_array($result);

// if(Is_array($row)){
//     $_SESSION["username"] = $row['username'];
//     $_SESSION["password"] = $row['password'];
// }

// else{
//     echo "no";
// }

?>