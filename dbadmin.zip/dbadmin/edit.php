<?php

$conn = mysqli_connect("localhost","root","","dashboard");
if (!$conn) {
    echo "connection refuse";
} else {
    echo "connection established";
}

$id=$_GET['id'];
$row = mysqli_fetch_assoc(mysqli_query($conn, "select * from products where id = '$id'"));


?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Add Products</title>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <link rel ="stylesheet" href="style.css">
</head>

<body id="form-bg">

<div class="container-form" id="form-cont">
    <form action="update.php" method="get">
    <div class="form-group">
    <input type="text" class="form-control" name="id" placeholder="id" value="<?php echo $row['id']?>" read-only>

    <input type="text"  value="<?= $row['name'] ?>"  class="form-control form-control-sm" id="colFormLabel" placeholder=" Enter your Name" name="name">

        <input type="text" class="form-control" name="category" placeholder="category" value="<?php echo $row['category']?> "required>

<input type="text" class="form-control" name="price" placeholder="Price" value="<?php echo $row['price']?> "required>


     <input type="number" class="form-control" name="quantity" placeholder="Quantity" value="<?php echo $row['quantity']?>" required>

    </div>
    <div class="button">
    <div id="button1" class="form-group"> 
            <input type="button" onclick="history.back();"class="btn btn-primary" value="Back" name="back">

</div>
    <div id="button2" class="form-group"> 
            <input type="submit"   class="btn btn-primary" value="submit">

</div>
</div>

    </form>
</div>


</body>
 




