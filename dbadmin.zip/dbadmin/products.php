<?php
$conn = mysqli_connect("localhost" ,"root", "", "dashboard");
if(!$conn){
    echo "connecttion unsuccessful";
}
else{
    echo "connection success";
}

$query = "select * from products;";

$result = mysqli_query($conn, $query);
?>




<!DOCTYPE html>
<html lang ="en">

<head>
<meta charset = "UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="style.css">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" integrity="sha384-DyZ88mC6Up2uqS4h/KRgHuoeGwBcD4Ng9SiP4dIRy0EXTlnuz47vAwmeGwVChigm" crossorigin="anonymous"/>
<script src="https://kit.fontawesome.com/e6da5eddfb.js" crossorigin="anonymous"></script>
</head>

<body>

<section id="sidebar">
    <div class="logo">
        <h2>My Dashboard</h2>
        <img src="images/dashboard-2.png" alt="">      
    </div>

    <div class="items">
        <ul>
        <li> <i class="fa-regular fa-chart-line"><a href="index.php">Dashboard</a></i></li>
      <!----  <li> <i class="fa-regular fa-user"><a href="#"> Users</a></i></li>-->
      <li> <i class="fa-regular fa-user"><a href="login.php">Admin</a></i></li>
      <div class="dropdown">
      <li class="dropbtn" style="border:none"> <i class="fa-regular fa-cart-shopping"><a href=products.php ">Products</a></i>
      <div class="dropdown-content">
<ul>
    <li><a href="products.php"> - Display Products</a></li>
    <li><a href="add.php"> - Add Product</a></li>
</ul>
</div>
    </li>
</div>



      <li> <i class="fa-regular fa-table"><a href="#">Tables</a></i></li>

      <li> <i class="fa-regular fa-chart-line"><a href="#">Charts</a></i>

</li>

    </ul>
    </div>
</section>


<section id="interface">
<div class="navigation" style=" width:calc(100%-300px)">
   <div class="n1">
    <div class="search">
        <i class="far fa-search"></i>
        <input type="text" placeholder="Search">
    </div>
   </div>
   <div class="profile">
    <h6>Account</h6>
    <img src="images/man.png">
   </div>
</div>

<h3 class="i-name">
    All Products
</h3>

<div class="board">
    <table width=100%>
        <thead>
    <tr id=#header>
        <td>ID</td>
        <td>Category</td>
        <td>Name</td>
        <td>Price</td>
        <td>Quanity</td>
        <td>Edit</td>
        <td>Delete</td>
    </tr>
</thead>

<tbody>
    <?php while ($row = mysqli_fetch_assoc($result)){?>
    <tr>
        <td><?php echo $row['id'];?></td>
        <td><?php echo $row['name'];?></td>
        <td><?php echo $row['category'];?></td>
        <td><?php echo $row['price'];?></td>
        <td><?php echo $row['quantity'];?></td>

        <td><a class='btn btn-primary btn-sm' style ="text-decoration:none ; color:blue;" href="edit.php?id=<?php echo $row['id']?>">Edit</a></td>
        <td><a class='btn btn-primary btn-danger' style ="text-decoration:none ; color:red;" href="delete.php?delete=<?php echo $row['id']?>">Delete</a></td>

    <tr>
    <?php } ?>
</tbody>
    </section>
    </table>
</div>
</html>


