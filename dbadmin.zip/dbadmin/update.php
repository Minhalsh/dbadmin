<?php 


// error_reporting(E_ALL); 
ini_set('display_errors', 1);

$conn = mysqli_connect("localhost" , "root", "" , "dashboard" );
if (!$conn) {
    echo "connection refuse";
} else {
    echo "connection established";
}

$id = $_GET['id'];
$category = $_GET['category'];
$name = $_GET['name'];
$price = $_GET'price'];
$quantity = $_GET['quantity'];

$query = "UPDATE `products` SET `category`='$category',`name`='$name',`price`='$price',`quantity`='$quantity' WHERE id=$id ";
$q = mysqli_query($conn, $query);
if(!$q){
    echo "connection unsuccessful";
}
else{
    echo "connection formed";

    
}    

// if(mysqli_affected_rows($conn) > 0){
//     echo "Record updated successfully";
//     header('Location: products.php');
// } else {
//     echo "Update failed";
// }

?> 

<?php 


// $conn = mysqli_connect("localhost" , "root", "" , "dashboard" );

// if (!$conn) {
//     echo "connection refused";
// } else {
//     echo "connection established";
// }

// $id = $_GET['id'];
// $category = $_POST['category'];
// $name = $_POST['name'];
// $price = $_POST['price'];
// $quantity = $_POST['quantity'];

// $query = "UPDATE `products` SET `category`=?, `name`=?, `price`=?, `quantity`=? WHERE `id`=?";
// $stmt = mysqli_prepare($conn, $query);

// mysqli_stmt_bind_param($stmt, "ssdii", $category, $name, $price, $quantity, $id);
// mysqli_stmt_execute($stmt);

// if(mysqli_affected_rows($conn) > 0){
//     echo "Record updated successfully";
//     header('Location: products.php');
// } else {
//     echo "Update failed";
// }

// mysqli_stmt_close($stmt);
// mysqli_close($conn);
?>

