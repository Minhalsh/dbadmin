<!-- <?php

$conn = mysqli_connect("localhost", "root", "", "dashboard");

$id=$_GET['delete'];
$query = "delete from products where id =$id";

$q = mysqli_query($conn, $query);

if(!$q){
    echo "connection unsuccessful";
}
else{
    echo "connection formed";
    header('Location:products.php');
}
?> -->


<?php



