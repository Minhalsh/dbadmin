<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Registration Form</title>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <link rel ="stylesheet" href="style.css">
</head>

<body style="background-color:#36454F;">
    <div class="container-signup">
    <form action="registration.php" method="post">
        <div class="form-group">
            <input type="text" class="form-control" name="username" placeholder="Full Name:" required>
        </div>
        <div class="form-group">
            <input type="email" class="form-control" name="email" placeholder="Email Address:">
        </div>
        <div class="form-group">
            <input type="tel" class="form-control" name="phone" placeholder="Phone no:">
        </div>

        <div class="form-group">
            <input type="password" class="form-control" name="password" placeholder="Password:">
        </div>
        
        <div class="form-group"> 
            <input type="submit" class="btn btn-primary" value="Register" name="submit" style="margin-left:220px;" >

</div>

    </form>
    </div>




</body>
<?php



 ?> 


<?php

//if isset('submit'){
$username = $_POST['username'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
//}

$conn = mysqli_connect("localhost", "root", "", "dashboard");         //hostname username password databasename
if (!$conn) {
    echo "connection refuse";
}

$query = "insert into admin values (null,'$username','$email','$phone','$password')";
$q = mysqli_query($conn, $query);
if (!$q) {
    echo "query unsuccessful";
} else {
    echo "query sucessful";
    
}




?>
<!-- <script>
window.location.assign("showdb.php");
</script> -->