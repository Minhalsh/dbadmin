<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Add Products</title>

        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <link rel ="stylesheet" href="style.css">
</head>

<body id="form-bg">

<div class="container-form">
    <form action="add.php" method="post">
    <div class="form-group">
        <input type="text" class="form-control" name="category" placeholder="Category" required>

        <input type="text" class="form-control" name="name" placeholder="Name" required>

<input type="text" class="form-control" name="price" placeholder="Price" required>


     <input type="number" class="form-control" name="quantity" placeholder="Quantity" required>

    </div>
    <div class="button">
    <div id="button1" class="form-group"> 
            <input type="button" onclick="history.back();"class="btn btn-primary" value="Back" name="back">

</div>
    <div id="button2" class="form-group"> 
            <input type="submit" class="btn btn-primary" value="Submit" name="submit">

</div>
</div>

    </form>
</div>


</body>


<!-- 



<?php

//if isset('submit'){
$category = $_POST['category'];
$name = $_POST['name'];
$price = $_POST['price'];
$quantity = $_POST['quantity'];
//}

$conn = mysqli_connect("localhost", "root", "", "dashboard");         //hostname username password databasename
if (!$conn) {
    echo "connection refuse";
}

$query = "insert into products values (null,'$category','$name','$price','$quantity')";
$q = mysqli_query($conn, $query);
if (!$q) {
    echo "query unsuccessful";
} else {
    echo "query sucessful";
    
}




?>
</html>








<?php>

$category=$_POST['category'];
$name = $_POST['name'];
$price = $_POST['price'];
$quantity=$_POST['quantity'];

$conn= mysqli_connect("localhost", "root", "", "dashboard");

$query = "insert into products values(null, "$category", "$name", "$price",'$quantity')";

$q = mysqli_query($conn, $query){
    if{$q}{
        echo "connected";
    }
    else{
        "connection failed";
    }
}



?> -->